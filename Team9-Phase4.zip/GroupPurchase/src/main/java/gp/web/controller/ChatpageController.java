package gp.web.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import gp.web.entity.Student;


@WebServlet("/chatpage")
public class ChatpageController extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		HttpSession session = req.getSession();
		boolean isLogin = false;
		String studentNum = null;
		if(session.getAttribute("isLogin")!= null)
			isLogin = (boolean) session.getAttribute("isLogin");
		if(session.getAttribute("loginNum") != null)
			studentNum = (String)session.getAttribute("loginNum");
		
		if(isLogin == false ||studentNum == null)
		{
			req.getSession().setAttribute("messageType", "���� �޽���");
			req.getSession().setAttribute("messageContent", "�α����� �Ǿ����� �ʽ��ϴ�");
			resp.sendRedirect("./login");
		}
		else
		{
			req.setAttribute("isLogin", isLogin);
			req.setAttribute("studentNum", studentNum);
			
			req.getRequestDispatcher("/WEB-INF/view/chat/chatpage.jsp").forward(req, resp); 
		}
	}
}
